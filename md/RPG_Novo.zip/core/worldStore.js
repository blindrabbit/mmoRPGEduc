// =============================================================================
// worldStore.js — mmoRPGGame  [FASE IMEDIATA — refatorado]
// Estado global do mundo — fonte única de verdade.
// Usado por: worldEngine.html, rpg.html, admin.html
//
// MUDANÇA: import { dbWatch } from './firebaseClient.js'
//       → import { watchMonsters, watchPlayers,
//                  watchEffects, watchFields } from './db.js'
//
// Nenhuma outra lógica foi alterada nesta fase.
// =============================================================================

// ✅ FASE IMEDIATA: só db.js, zero firebaseClient direto
import {
  watchMonsters,
  watchPlayers,
  watchEffects,
  watchFields,
  dbGet,
  PATHS,
} from "./db.js";
import {
  inferSpeciesFromName,
  getMonsterTemplates,
} from "./remoteTemplates.js";
import { normalizeCollection } from "./schema.js";

// ---------------------------------------------------------------------------
// ESTADO INTERNO
// ---------------------------------------------------------------------------
const state = {
  monsters: {}, // world_entities  (type: monster)
  players: {}, // online_players
  effects: {}, // world_effects
  fields: {}, // world_fields
};

// Subscribers por canal
const subs = {
  monsters: new Set(),
  players: new Set(),
  effects: new Set(),
  fields: new Set(),
};

// Flag exposta para o worldEngine bloquear durante o tick
export let tickRunning = false;
export function setTickRunning(val) {
  tickRunning = val;
}

// ---------------------------------------------------------------------------
// INIT — chame uma vez no boot de qualquer tela
// ---------------------------------------------------------------------------
let initialized = false;

export function initWorldStore() {
  if (initialized) return;
  initialized = true;

  // world_entities — monstros
  watchMonsters((data) => {
    if (tickRunning) return; // WorldEngine não sobrescreve durante tick
    mergeMonsters(normalizeCollection(data, "monster"));
    notify("monsters", state.monsters);
  });

  // também faz uma leitura pontual imediata para garantir que qualquer
  // monstro persistido *antes* da conexão seja carregado mesmo que o
  // watcher não tenha disparado ainda (problema raro com onValue).
  dbGet(PATHS.monsters)
    .then((initial) => {
      if (initial) {
        mergeMonsters(normalizeCollection(initial, "monster"));
        notify("monsters", state.monsters);
        // console.log("[worldStore] initial monsters fetched", Object.keys(state.monsters).length);
      }
    })
    .catch((e) => {
      console.warn("[worldStore] failed to fetch initial monsters", e);
    });

  // online_players — jogadores
  watchPlayers((data) => {
    mergePlayers(normalizeCollection(data, "player"));
    notify("players", state.players);
  });

  // world_effects — efeitos visuais e cadáveres
  watchEffects((data) => {
    state.effects = normalizeCollection(data, "effect");
    notify("effects", state.effects);
  });

  // world_fields — campos persistentes (fogo, veneno, etc.)
  watchFields((data) => {
    state.fields = normalizeCollection(data, "field");
    notify("fields", state.fields);
  });
}

// ---------------------------------------------------------------------------
// GETTERS
// ---------------------------------------------------------------------------
export const getMonsters = () => state.monsters;
export const getPlayers = () => state.players;
export const getEffects = () => state.effects;
export const getFields = () => state.fields;

// ---------------------------------------------------------------------------
// SETTER — usado pelo monsterManager via applyToMob
// Atualiza só o estado local sem sobrescrever campos de IA
// ---------------------------------------------------------------------------
export function applyMonstersLocal(id, obj) {
  if (!state.monsters[id]) state.monsters[id] = {};
  Object.assign(state.monsters[id], obj);
  // Não notifica subscribers — mudança local de IA, não visual
}

// ---------------------------------------------------------------------------
// SUBSCRIBE — qualquer tela recebe updates em tempo real
// canal: 'monsters' | 'players' | 'effects' | 'fields'
// ---------------------------------------------------------------------------
export function subscribe(canal, cb) {
  subs[canal].add(cb);
  // Dispara imediatamente com o estado atual se já tiver dados
  const current = state[canal];
  if (Object.keys(current).length > 0) cb(current);
  return () => subs[canal].delete(cb); // retorna unsubscribe
}

// ---------------------------------------------------------------------------
// INTERNOS
// ---------------------------------------------------------------------------
function notify(canal, data) {
  for (const cb of subs[canal]) cb(data);
}

// Mescla monstros preservando campos de controle de IA
function mergeMonsters(incoming) {
  if (!incoming) {
    // Firebase deletou o nó inteiro (ex: clearMonsters)
    state.monsters = {};
    return;
  }

  // Remove entidades deletadas do Firebase
  for (const id in state.monsters) {
    if (!incoming[id]) delete state.monsters[id];
  }

  // Mescla entidades existentes e adiciona novas
  for (const id in incoming) {
    // normalize: if entry looks like a monster but has no type, add it
    const entry = incoming[id];
    if (entry && !entry.type) {
      if (
        typeof entry.species === "string" ||
        id.startsWith("mob") ||
        (!!entry.stats && !entry.type)
      ) {
        entry.type = "monster";
      }
    }
    // infer species by name when it's missing (helps renderers and AI)
    if (entry && entry.type === "monster" && !entry.species && entry.name) {
      const inferred = inferSpeciesFromName(entry.name);
      if (inferred) {
        entry.species = inferred;
      }
    }

    if (!state.monsters[id]) {
      // Entidade nova: aceita direto
      // Se é nova e tem posição, marca o timestamp do movimento agora
      // para que a interpolação comece corretamente
      if (entry.x != null && entry.y != null && !entry.lastMoveTime) {
        entry.lastMoveTime = Date.now();
      }
      state.monsters[id] = entry;
    } else {
      // Entidade existente: preserva campos de IA
      const local = state.monsters[id];
      // log when incoming is missing crucial positional data
      // if (entry.x == null || entry.y == null) {
      //   console.warn(`[mergeMonsters] partial update dropping coords for ${id}`, entry);
      // }

      // ✅ DETECTA MOVIMENTO: se x ou y mudaram, atualiza lastMoveTime
      const newX = entry.x != null ? entry.x : local.x;
      const newY = entry.y != null ? entry.y : local.y;
      const moved = newX !== local.x || newY !== local.y;

      // Se monstro se moveu e servidor não enviou timestamp novo,
      // atualiza para agora (permite interpolação visual)
      let moveTimestamp = entry.lastMoveTime ?? local.lastMoveTime;
      if (moved && !entry.lastMoveTime) {
        moveTimestamp = Date.now();
        console.debug(
          `[mergeMonsters] movement detected for ${id}, updating lastMoveTime`,
        );
      }

      // Se monstro se moveu, preserva posição antiga para interpolação
      let oldXForInterp = local.oldX;
      let oldYForInterp = local.oldY;
      if (moved) {
        oldXForInterp = local.x;
        oldYForInterp = local.y;
      }

      // merge incoming monster with local state, but allow server timestamps
      // (moveTime/attack/etc) to override so clients like RPG see fresh values.
      // if the incoming update explicitly wipes the name, keep the old one
      if (entry && entry.name == null && local.name) {
        entry.name = local.name;
      }

      let merged = {
        // start with the local state, then overwrite with any fields that
        // actually exist in the incoming entry to treat the update as
        // partial rather than replace-all. undefined values in `entry`
        // should not erase existing data.
        ...local,
        ...entry,
        lastAiTick: local.lastAiTick ?? entry.lastAiTick,
        lastAttack: local.lastAttack ?? entry.lastAttack,
        lastMoveTime: moveTimestamp,
        dead: entry.dead ?? local.dead,
        // keep position/direction unless server explicitly provides them
        x: newX,
        y: newY,
        z: entry.z != null ? entry.z : local.z,
        direcao: entry.direcao != null ? entry.direcao : local.direcao,
        // preserve visual interpolation state so movement is detected
        oldX: oldXForInterp ?? entry.oldX,
        oldY: oldYForInterp ?? entry.oldY,
        // Preserva todos os campos de cooldown de IA (cdXxx)
        ...Object.fromEntries(
          Object.entries(local).filter(([k]) => k.startsWith("cd")),
        ),
      };

      // If after merge the monster still lacks a name, try to fill it from
      // the template list (which is synced separately). This covers monsters
      // spawned automatically without admin-provided name.
      if (!merged.name && merged.species) {
        const remote = getMonsterTemplates();
        if (remote && remote[merged.species]?.name) {
          merged.name = remote[merged.species].name;
        }
      }

      state.monsters[id] = merged;
    }
  }
}

// Mescla players preservando interpolação local de movimento
function mergePlayers(incoming) {
  if (!incoming) {
    state.players = {};
    return;
  }

  for (const id in state.players) {
    if (!incoming[id]) delete state.players[id];
  }

  for (const id in incoming) {
    const entry = incoming[id];

    if (!state.players[id]) {
      if (entry.x != null && entry.y != null && !entry.lastMoveTime) {
        entry.lastMoveTime = Date.now();
      }
      state.players[id] = entry;
      continue;
    }

    const local = state.players[id];
    const newX = entry.x != null ? entry.x : local.x;
    const newY = entry.y != null ? entry.y : local.y;
    const moved = newX !== local.x || newY !== local.y;

    let moveTimestamp = entry.lastMoveTime ?? local.lastMoveTime;
    if (moved) {
      moveTimestamp = Date.now();
    }

    let oldXForInterp = local.oldX;
    let oldYForInterp = local.oldY;
    if (moved) {
      oldXForInterp = local.x;
      oldYForInterp = local.y;
    }

    state.players[id] = {
      ...local,
      ...entry,
      x: newX,
      y: newY,
      z: entry.z != null ? entry.z : local.z,
      direcao: entry.direcao != null ? entry.direcao : local.direcao,
      lastMoveTime: moveTimestamp,
      oldX: oldXForInterp ?? entry.oldX,
      oldY: oldYForInterp ?? entry.oldY,
    };
  }
}
