// ═══════════════════════════════════════════════════════════════
// firebaseClient.js — Conexão e helpers do Firebase
// Responsabilidade: APENAS comunicação com o banco.
// REGRA: Nenhum outro arquivo importa este módulo — apenas db.js.
// ═══════════════════════════════════════════════════════════════

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.5.0/firebase-app.js";
import {
  getDatabase,
  ref,
  get,
  set,
  update,
  remove,
  onValue,
} from "https://www.gstatic.com/firebasejs/10.5.0/firebase-database.js";

const firebaseConfig = {
  apiKey           : "AIzaSyD-jncgTANFm2WoCMNAYg0SvEV9THOUPyg",
  authDomain       : "aula-apw.firebaseapp.com",
  databaseURL      : "https://aula-apw-default-rtdb.firebaseio.com",
  projectId        : "aula-apw",
  storageBucket    : "aula-apw.appspot.com",
  messagingSenderId: "534057882433",
  appId            : "1:534057882433:web:a85b3a4d0af2bb5afa47c0",
};

export const app = initializeApp(firebaseConfig);
export const db  = getDatabase(app);

// ---------------------------------------------------------------------------
// LEITURA
// ---------------------------------------------------------------------------

/** Lê uma vez o valor de um path. */
export async function dbGet(path) {
  const snap = await get(ref(db, path));
  return snap.val();
}

// ---------------------------------------------------------------------------
// ESCRITA SIMPLES
// ---------------------------------------------------------------------------

/** Sobrescreve completamente um path. */
export function dbSet(path, data) {
  return set(ref(db, path), data);
}

/**
 * ✅ CORRIGIDO — Multi-path update.
 *
 * Aceita UM objeto cujas chaves são paths completos e os valores são os dados.
 * Isso permite atualizar múltiplos nós em uma única operação atômica.
 *
 * Uso correto (db.js):
 *   dbUpdate({
 *     'players_data/id123/stats': { hp: 80 },
 *     'online_players/id123/stats': { hp: 80 },
 *   });
 *
 * NÃO use dbUpdate(path, data) — use dbSet(path, data) para escrita simples.
 */
export function dbUpdate(updates) {
  return update(ref(db), updates);
}

/** Remove um path do banco. */
export function dbRemove(path) {
  return remove(ref(db, path));
}

// ---------------------------------------------------------------------------
// ESCUTA EM TEMPO REAL
// ---------------------------------------------------------------------------

/**
 * Escuta mudanças em tempo real em um path.
 * @returns {function} unsubscribe — chame para parar de escutar
 */
export function dbWatch(path, cb) {
  return onValue(ref(db, path), (snap) => cb(snap.val()));
}

// ---------------------------------------------------------------------------
// SYNC DE ENTIDADE (upsert / delete)
// ---------------------------------------------------------------------------

/**
 * Atualiza (data !== null) ou remove (data === null) um nó no Firebase.
 * @param {string} path  — caminho completo, ex: 'online_players/id123'
 * @param {object|null} data
 */
export function syncEntity(path, data) {
  return data !== null
    ? update(ref(db, path), data)
    : set(ref(db, path), null);
}

// ---------------------------------------------------------------------------
// RELÓGIO DO SERVIDOR
// ---------------------------------------------------------------------------

/**
 * Escuta o offset do servidor e chama cb(offsetMs) a cada sincronização.
 * @returns {function} unsubscribe
 */
export function dbWatchServerTime(onOffset) {
  return onValue(ref(db, "worldstate/serverTime"), (snap) => {
    if (snap.exists()) onOffset(Date.now() - snap.val());
  });
}
