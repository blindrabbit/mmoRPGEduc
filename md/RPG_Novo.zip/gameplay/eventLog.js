// ═══════════════════════════════════════════════════════════════
// eventLog.js — Painel de log unificado com deduplicação
// Usado por: worldEngine.html, RPG.html, ADMIN.html
// ═══════════════════════════════════════════════════════════════

const ICONS = {
  damage: "⚔️",
  death_player: "💀",
  death_monster: "🐉",
  heal: "💚",
  system: "⚙️",
  spawn: "🐾",
  move: "👣",
  field: "🔥",
  loot: "🎁",
  warn: "⚠️",
  error: "❌",
  rpg: "🎮",
  admin: "🛡️",
  engine: "🌐",
};

const TYPE_COLORS = {
  damage: "#e74c3c",
  death_player: "#e74c3c",
  death_monster: "#f39c12",
  heal: "#2ecc71",
  system: "#95a5a6",
  spawn: "#9b59b6",
  move: "#7f8c8d",
  field: "#e67e22",
  loot: "#f1c40f",
  warn: "#f1c40f",
  error: "#e74c3c",
};

// ─── Estado do painel ──────────────────────────────────────────
let _panel = null;
let _opts = {};
let _lastEntry = null; // { key, el, countEl, tsEl, count }

// ─── Chave de deduplicação ─────────────────────────────────────
// Duas mensagens são "iguais" se têm o mesmo tipo + texto principal
function dedupKey(source, type, msg, detail) {
  return `${source}|${type}|${msg}`;
}

function nowTS() {
  return new Date().toLocaleTimeString("pt-BR", { hour12: false });
}

// ═══════════════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════════════
export function initEventLog(opts = {}) {
  _opts = {
    panelId: "log-panel",
    showSource: true,
    maxLines: 120,
    filters: ["all"],
    ...opts,
  };

  _panel = document.getElementById(_opts.panelId);
  if (!_panel) return;

  // ── Header do painel ────────────────────────────────────────
  const header = document.createElement("div");
  header.style.cssText = [
    "display:flex",
    "align-items:center",
    "justify-content:space-between",
    "padding:6px 10px",
    "background:#0d1117",
    "border-bottom:1px solid #1a2a3a",
    "flex-shrink:0",
  ].join(";");

  const title = document.createElement("span");
  title.style.cssText =
    "color:#2ecc71;font:bold 11px monospace;letter-spacing:1px";
  title.textContent = "◈ EVENT LOG";

  const clearBtn = document.createElement("button");
  clearBtn.textContent = "limpar";
  clearBtn.style.cssText = [
    "background:none",
    "border:1px solid #333",
    "color:#666",
    "font:10px monospace",
    "padding:2px 8px",
    "cursor:pointer",
    "border-radius:3px",
  ].join(";");
  clearBtn.onclick = () => {
    if (_body) _body.innerHTML = "";
    _lastEntry = null;
  };

  header.appendChild(title);
  header.appendChild(clearBtn);
  _panel.appendChild(header);

  // ── Corpo scrollável ─────────────────────────────────────────
  _body = document.createElement("div");
  _body.style.cssText = [
    "flex:1",
    "overflow-y:auto",
    "padding:4px 0",
    "font:11px monospace",
    "scrollbar-width:thin",
    "scrollbar-color:#1a2a3a #0d1117",
  ].join(";");
  _panel.appendChild(_body);
}

let _body = null;

// ═══════════════════════════════════════════════════════════════
// pushLog — API pública
// pushLog(type, msg, detail?)
// pushLog(source, type, msg, detail?)
// ═══════════════════════════════════════════════════════════════
export function pushLog(sourceOrType, typeOrMsg, msgOrDetail, detailOrUndef) {
  let source, type, msg, detail;

  // Suporta assinatura com 3 ou 4 args
  if (detailOrUndef !== undefined) {
    // pushLog(source, type, msg, detail)
    [source, type, msg, detail] = [
      sourceOrType,
      typeOrMsg,
      msgOrDetail,
      detailOrUndef,
    ];
  } else if (msgOrDetail !== undefined) {
    // pushLog(source, type, msg)  ou  pushLog(type, msg, detail)
    // Heurística: se typeOrMsg é um tipo conhecido → (source, type, msg)
    const knownTypes = Object.keys(ICONS);
    if (knownTypes.includes(typeOrMsg)) {
      [source, type, msg, detail] = [
        sourceOrType,
        typeOrMsg,
        msgOrDetail,
        undefined,
      ];
    } else {
      [source, type, msg, detail] = ["", sourceOrType, typeOrMsg, msgOrDetail];
    }
  } else {
    // pushLog(type, msg)
    [source, type, msg, detail] = ["", sourceOrType, typeOrMsg, undefined];
  }

  if (!_body) return;

  // ── Filtro ───────────────────────────────────────────────────
  const filters = _opts.filters || ["all"];
  if (!filters.includes("all") && !filters.includes(type)) return;

  const ts = nowTS();
  const key = dedupKey(source, type, msg, detail);

  // ── Deduplicação — mesma chave = atualiza linha existente ───
  if (_lastEntry && _lastEntry.key === key) {
    _lastEntry.count++;
    _lastEntry.tsEl.textContent = ts;
    _lastEntry.countEl.textContent = ` ×${_lastEntry.count}`;
    _lastEntry.countEl.style.display = "inline";
    // Atualiza detail se mudou (ex: HP diferente)
    if (detail !== undefined && _lastEntry.detailEl) {
      _lastEntry.detailEl.textContent = detail;
    }
    _body.scrollTop = _body.scrollHeight;
    return;
  }

  // ── Nova linha ───────────────────────────────────────────────
  const row = document.createElement("div");
  row.style.cssText = [
    "display:flex",
    "align-items:baseline",
    "gap:4px",
    "padding:3px 10px",
    "border-bottom:1px solid #0d1117",
    "line-height:1.6",
    "transition:background 0.2s",
  ].join(";");
  row.onmouseenter = () => {
    row.style.background = "#111827";
  };
  row.onmouseleave = () => {
    row.style.background = "";
  };

  // timestamp
  const tsEl = document.createElement("span");
  tsEl.style.cssText =
    "color:#4a5568;font-size:10px;flex-shrink:0;min-width:56px";
  tsEl.textContent = ts;

  // ícone + source badge
  const icon = ICONS[type] || "•";
  const iconEl = document.createElement("span");
  iconEl.textContent = icon;
  iconEl.style.cssText = "flex-shrink:0";

  // source badge (opcional)
  let badgeEl = null;
  if (_opts.showSource && source) {
    badgeEl = document.createElement("span");
    badgeEl.textContent = source;
    badgeEl.style.cssText = [
      `color:${TYPE_COLORS[source] || "#7f8c8d"}`,
      "font-size:9px",
      "opacity:0.7",
      "flex-shrink:0",
      "text-transform:uppercase",
      "letter-spacing:0.5px",
    ].join(";");
  }

  // mensagem principal
  const msgEl = document.createElement("span");
  msgEl.textContent = msg;
  msgEl.style.cssText = `color:${TYPE_COLORS[type] || "#ccc"};flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap`;

  // detail
  let detailEl = null;
  if (detail !== undefined) {
    detailEl = document.createElement("span");
    detailEl.textContent = detail;
    detailEl.style.cssText =
      "color:#4a5568;font-size:10px;flex-shrink:0;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap";
  }

  // contador de repetições (oculto por padrão)
  const countEl = document.createElement("span");
  countEl.style.cssText =
    "color:#f1c40f;font-size:10px;flex-shrink:0;display:none";

  // monta linha
  row.appendChild(tsEl);
  row.appendChild(iconEl);
  if (badgeEl) row.appendChild(badgeEl);
  row.appendChild(msgEl);
  if (detailEl) row.appendChild(detailEl);
  row.appendChild(countEl);

  _body.appendChild(row);
  _body.scrollTop = _body.scrollHeight;

  // ── Salva como última entrada para deduplicação ─────────────
  _lastEntry = { key, el: row, tsEl, countEl, detailEl, count: 1 };

  // ── Limite de linhas ─────────────────────────────────────────
  const maxLines = _opts.maxLines || 120;
  while (_body.children.length > maxLines) {
    _body.removeChild(_body.firstChild);
    // Se removeu a linha deduplicada, reseta
    if (_lastEntry && !_body.contains(_lastEntry.el)) _lastEntry = null;
  }
}
