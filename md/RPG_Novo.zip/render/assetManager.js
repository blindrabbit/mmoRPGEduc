// ═══════════════════════════════════════════════════════════════
// assetManager.js — Gerenciador de sprites e packs de assets
// Usado por: rpg.html, gm.html, worldEngine.html, assetLoader.js
// ═══════════════════════════════════════════════════════════════

export class AssetManager {
  constructor() {
    this.sprites = new Map(); // itemid (number) → { sheet, x, y, w, h }
    this.packs = {}; // nome → { image, data }
    this.effectsAtlas = null; // { image, data, frameKeyCache }
    this.outfitsAtlas = null; // { image, data, outfitCache }
    this.fieldsAtlas = null; // { image, data }
  }

  // ═══════════════════════════════════════════════════════════════
  // API OTBM — sprites de mapa por itemid numérico
  // ═══════════════════════════════════════════════════════════════

  async loadSpriteSheet(name, imgUrl, itemMap) {
    const img = await this._loadImage(imgUrl);
    if (!img) return 0;

    let count = 0;
    for (const [id, frame] of Object.entries(itemMap)) {
      this.sprites.set(Number(id), { sheet: img, ...frame });
      count++;
    }

    console.log(`[AssetManager] ✅ "${name}" — ${count} sprites de mapa.`);
    return count;
  }

  getSpriteById(itemid) {
    return this.sprites.get(Number(itemid)) ?? null;
  }

  // ═══════════════════════════════════════════════════════════════
  // API PACKS — outfits, effects, monstros
  // ═══════════════════════════════════════════════════════════════

  async loadPack(name, imgUrl, jsonUrl) {
    try {
      const [img, data] = await Promise.all([
        this._loadImage(imgUrl),
        fetch(jsonUrl).then((r) => r.json()),
      ]);
      if (img && data) {
        this.packs[name] = { image: img, data };
        return true;
      }
      return false;
    } catch (e) {
      console.error(`[AssetManager] Erro no pack "${name}":`, e);
      return false;
    }
  }

  getSprite(packName, spriteName) {
    const pack = this.packs[packName];
    if (!pack?.data?.frames?.[spriteName]) return null;
    const f = pack.data.frames[spriteName].frame;
    return { sheet: pack.image, info: { x: f.x, y: f.y, w: f.w, h: f.h } };
  }

  // ═══════════════════════════════════════════════════════════════
  // API OUTFITS ATLAS (novo formato outfits_players_data.json)
  // ═══════════════════════════════════════════════════════════════

  async loadOutfitsAtlas(imgUrl, jsonUrl) {
    try {
      const [img, data] = await Promise.all([
        this._loadImage(imgUrl),
        fetch(jsonUrl).then((r) => r.json()),
      ]);
      if (!img || !data) return false;

      this.outfitsAtlas = {
        image: img,
        data,
        outfitCache: new Map(),
      };
      return true;
    } catch (e) {
      console.error("[AssetManager] Erro no outfits atlas:", e);
      return false;
    }
  }

  hasOutfitsAtlas() {
    return !!this.outfitsAtlas?.image && !!this.outfitsAtlas?.data;
  }

  hasOutfitDefinition(outfitId) {
    if (!this.hasOutfitsAtlas()) return false;
    const key = String(outfitId);
    return !!this.outfitsAtlas.data?.outfits?.[key];
  }

  _normalizeAddonSelection(addons) {
    if (!addons) return { addon1: false, addon2: false, addon3: false };

    if (typeof addons === "number") {
      return {
        addon1: (addons & 1) !== 0,
        addon2: (addons & 2) !== 0,
        addon3: (addons & 4) !== 0,
      };
    }

    if (Array.isArray(addons)) {
      return {
        addon1: addons.includes(1) || addons.includes("1"),
        addon2: addons.includes(2) || addons.includes("2"),
        addon3: addons.includes(3) || addons.includes("3"),
      };
    }

    if (typeof addons === "object") {
      return {
        addon1: Boolean(addons.addon1),
        addon2: Boolean(addons.addon2),
        addon3: Boolean(addons.addon3),
      };
    }

    return { addon1: false, addon2: false, addon3: false };
  }

  _resolveAddonDrawPlan(_group, addonSelection) {
    // Hook futuro: mapear addonSelection para patternY/layers específicas.
    // Por enquanto, desenha apenas camada base (sem addons) para evitar sobreposição.
    return {
      yIndex: null,
      layersToDraw: [0],
      addonSelection,
    };
  }

  getOutfitSprites(outfitId, options = {}) {
    if (!this.hasOutfitsAtlas()) return [];

    const key = String(outfitId);
    const outfit = this.outfitsAtlas.data?.outfits?.[key];
    if (!outfit?.groups?.length) return [];

    const groups = Array.isArray(outfit.groups) ? outfit.groups : [];
    const baseGroup =
      groups.find((g) => Number(g?.fixed_frame_group) === 0) ?? groups[0];
    const animGroup =
      groups.find((g) => Number(g?.fixed_frame_group) === 1) ?? baseGroup;

    const step = Number(options.step ?? 1);
    const isMoving = step !== 1;
    const group = isMoving ? animGroup : baseGroup;
    if (!group) return [];

    const pattern = group.pattern ?? {};
    const width = Math.max(1, Number(pattern.width ?? 1));
    const height = Math.max(1, Number(pattern.height ?? 1));
    const depth = Math.max(1, Number(pattern.depth ?? 1));
    const layers = Math.max(1, Number(pattern.layers ?? 1));

    const spriteIds = Array.isArray(group.sprite_ids) ? group.sprite_ids : [];
    if (!spriteIds.length) return [];

    const spritesPerFrame = Math.max(
      1,
      Number(group.sprites_per_frame ?? width * height * depth * layers),
    );
    const frameCount = Math.max(
      1,
      Number(group.n_frames ?? Math.floor(spriteIds.length / spritesPerFrame) ?? 1),
    );

    const dir = String(options.dir ?? "frente");
    const elapsedMs = Math.max(0, Number(options.elapsedMs ?? 0));
    const animationTimeMs = Math.max(
      0,
      Number(options.animationTimeMs ?? Date.now()),
    );
    const includeColorMask = options.includeColorMask === true;
    const addonSelection = this._normalizeAddonSelection(options.addons);
    const addonPlan = this._resolveAddonDrawPlan(group, addonSelection);

    const dirCoordMap = {
      costas: { x: 0, y: 0 },
      frente: { x: 0, y: 1 },
      lado: { x: 2, y: 0 },
      "lado-esquerdo": { x: 2, y: 1 },
    };
    const primaryCoord = dirCoordMap[dir] ?? dirCoordMap.costas;
    const primaryDirIndex = Math.max(0, Math.min(width - 1, Number(primaryCoord.x ?? 0)));
    const dirCandidates = [
      primaryDirIndex,
      0,
      2,
      1,
      3,
    ].filter((value, idx, arr) => value >= 0 && value < width && arr.indexOf(value) === idx);

    let frameIndex = 0;
    if (frameCount > 1) {
      if (!isMoving) {
        frameIndex = 0;
      } else {
        const phases = Array.isArray(group?.animation?.phases)
          ? group.animation.phases
          : [];
        if (phases.length > 0) {
          const durations = [];
          for (let index = 0; index < frameCount; index++) {
            const phase = phases[index] ?? phases[phases.length - 1] ?? null;
            const dMin = Number(phase?.d_min ?? 120);
            const dMax = Number(phase?.d_max ?? dMin);
            durations.push(Math.max(1, Math.round((dMin + dMax) / 2)));
          }
          const total = durations.reduce((sum, d) => sum + d, 0);
          const t = total > 0 ? animationTimeMs % total : 0;

          let acc = 0;
          for (let i = 0; i < durations.length; i++) {
            acc += durations[i];
            if (t < acc) {
              frameIndex = Math.min(i, frameCount - 1);
              break;
            }
          }
        } else {
          frameIndex = Math.floor(animationTimeMs / 120) % frameCount;
        }
      }
    }
    frameIndex = Math.max(0, Math.min(frameCount - 1, frameIndex));

    const frameBase = frameIndex * spritesPerFrame;
    const yIndex = Math.max(
      0,
      Math.min(height - 1, Number(addonPlan?.yIndex ?? primaryCoord.y ?? 0)),
    );
    const layersToDraw = Array.isArray(addonPlan?.layersToDraw)
      ? addonPlan.layersToDraw
          .map((value) => Number(value))
          .filter((value) => Number.isFinite(value) && value >= 0 && value < layers)
      : [0];

    const resolveSpriteIdAtXDepth = (xIndex, depthIndex) => {
      const refs = [];
      for (const layer of layersToDraw.length ? layersToDraw : [0]) {
        const idx =
          frameBase +
          (((layer * depth + depthIndex) * height + yIndex) * width + xIndex);
        refs.push(spriteIds[idx]);
      }
      return refs;
    };

    const resolveBestDepthAtX = (xIndex) => {
      let bestRefs = [];
      let bestScore = -1;

      for (let depthIndex = 0; depthIndex < depth; depthIndex++) {
        const refs = resolveSpriteIdAtXDepth(xIndex, depthIndex);
        let visibleCount = 0;
        for (const spriteId of refs) {
          if (spriteId == null) continue;
          const variant = this.outfitsAtlas.data?.sprites?.[String(spriteId)];
          if (variant && !variant.transparent) visibleCount++;
        }
        if (visibleCount > bestScore) {
          bestScore = visibleCount;
          bestRefs = refs;
        }
      }

      return bestRefs;
    };

    let selectedRefs = [];
    for (const xIndex of dirCandidates) {
      const refs = resolveBestDepthAtX(
        Math.max(0, Math.min(width - 1, xIndex)),
      );
      const hasAny = refs.some((sid) => sid != null);
      if (hasAny) {
        selectedRefs = refs;
        break;
      }
    }
    if (!selectedRefs.length) {
      selectedRefs = resolveBestDepthAtX(0);
    }

    const sprites = [];
    for (const spriteId of selectedRefs) {
      if (spriteId == null) continue;
      const variant = this.outfitsAtlas.data?.sprites?.[String(spriteId)];
      if (!variant || variant.transparent) continue;

      sprites.push({
        sheet: this.outfitsAtlas.image,
        info: {
          x: Number(variant.x ?? 0),
          y: Number(variant.y ?? 0),
          w: Number(variant.w ?? 32),
          h: Number(variant.h ?? 32),
        },
        spriteId: Number(spriteId),
        isColorMask: false,
      });

      if (includeColorMask) {
        const maskSpriteId = Number(spriteId) + 1;
        const maskVariant = this.outfitsAtlas.data?.sprites?.[
          String(maskSpriteId)
        ];
        if (maskVariant && !maskVariant.transparent) {
          sprites.push({
            sheet: this.outfitsAtlas.image,
            info: {
              x: Number(maskVariant.x ?? 0),
              y: Number(maskVariant.y ?? 0),
              w: Number(maskVariant.w ?? 32),
              h: Number(maskVariant.h ?? 32),
            },
            spriteId: maskSpriteId,
            isColorMask: true,
          });
        }
      }
    }

    return sprites;
  }

  // ═══════════════════════════════════════════════════════════════
  // API FIELDS ATLAS (novo formato fields_data.json)
  // ═══════════════════════════════════════════════════════════════

  async loadFieldsAtlas(imgUrl, jsonUrl) {
    try {
      const [img, data] = await Promise.all([
        this._loadImage(imgUrl),
        fetch(jsonUrl).then((r) => r.json()),
      ]);
      if (!img || !data) return false;

      this.fieldsAtlas = {
        image: img,
        data,
      };
      return true;
    } catch (e) {
      console.error("[AssetManager] Erro no fields atlas:", e);
      return false;
    }
  }

  hasFieldsAtlas() {
    return !!this.fieldsAtlas?.image && !!this.fieldsAtlas?.data;
  }

  hasFieldDefinition(fieldId) {
    if (!this.hasFieldsAtlas()) return false;
    const key = String(fieldId);
    return !!this.fieldsAtlas.data?.fields?.[key];
  }

  getFieldSprites(fieldId, elapsedMs = 0, options = {}) {
    if (!this.hasFieldsAtlas()) return [];

    const key = String(fieldId);
    const field = this.fieldsAtlas.data?.fields?.[key];
    if (!field?.groups?.length) return [];

    const groups = Array.isArray(field.groups) ? field.groups : [];
    const group =
      groups.find((g) => Number(g?.fixed_frame_group) === 2) ??
      groups.find((g) => Number(g?.fixed_frame_group) === 1) ??
      groups.find((g) => Number(g?.fixed_frame_group) === 0) ??
      groups[0];
    if (!group) return [];

    const pattern = group.pattern ?? {};
    const width = Math.max(1, Number(pattern.width ?? 1));
    const height = Math.max(1, Number(pattern.height ?? 1));
    const depth = Math.max(1, Number(pattern.depth ?? 1));
    const layers = Math.max(1, Number(pattern.layers ?? 1));
    const spriteIds = Array.isArray(group.sprite_ids) ? group.sprite_ids : [];
    if (!spriteIds.length) return [];

    const spritesPerFrame = Math.max(
      1,
      Number(group.sprites_per_frame ?? width * height * depth * layers),
    );
    const frameCount = Math.max(
      1,
      Number(group.n_frames ?? Math.floor(spriteIds.length / spritesPerFrame) ?? 1),
    );

    let frameIndex = 0;
    if (frameCount > 1) {
      const phases = Array.isArray(group?.animation?.phases)
        ? group.animation.phases
        : [];

      if (phases.length > 0) {
        const durations = [];
        for (let index = 0; index < frameCount; index++) {
          const phase = phases[index] ?? phases[phases.length - 1] ?? null;
          const dMin = Number(phase?.d_min ?? 120);
          const dMax = Number(phase?.d_max ?? dMin);
          durations.push(Math.max(1, Math.round((dMin + dMax) / 2)));
        }

        const total = durations.reduce((sum, value) => sum + value, 0);
        const t = total > 0 ? Math.max(0, Number(elapsedMs ?? 0)) % total : 0;

        let acc = 0;
        for (let i = 0; i < durations.length; i++) {
          acc += durations[i];
          if (t < acc) {
            frameIndex = i;
            break;
          }
        }
      } else {
        frameIndex = Math.floor(Math.max(0, Number(elapsedMs ?? 0)) / 120) % frameCount;
      }
    }
    frameIndex = Math.max(0, Math.min(frameCount - 1, frameIndex));

    const xTile = Number(options.x ?? 0);
    const yTile = Number(options.y ?? 0);
    const seed = Number(options.seed ?? 0) || 0;
    const variantCount = Math.max(1, width * height);
    const hashRaw = (xTile * 73856093) ^ (yTile * 19349663) ^ seed;
    const variantIndex = Math.abs(hashRaw) % variantCount;
    const xIndex = Math.max(0, Math.min(width - 1, variantIndex % width));
    const yIndex = Math.max(0, Math.min(height - 1, Math.floor(variantIndex / width)));

    const frameBase = frameIndex * spritesPerFrame;
    const depthIndex = 0;
    const refs = [];
    for (let layer = 0; layer < layers; layer++) {
      const idx =
        frameBase +
        (((layer * depth + depthIndex) * height + yIndex) * width + xIndex);
      refs.push(spriteIds[idx]);
    }

    const sprites = [];
    for (const spriteId of refs) {
      if (spriteId == null) continue;
      const variant = this.fieldsAtlas.data?.sprites?.[String(spriteId)];
      if (!variant || variant.transparent) continue;

      sprites.push({
        sheet: this.fieldsAtlas.image,
        info: {
          x: Number(variant.x ?? 0),
          y: Number(variant.y ?? 0),
          w: Number(variant.w ?? 32),
          h: Number(variant.h ?? 32),
        },
      });
    }

    return sprites;
  }

  // ═══════════════════════════════════════════════════════════════
  // API EFFECTS ATLAS (novo formato effects_data.json)
  // ═══════════════════════════════════════════════════════════════

  async loadEffectsAtlas(imgUrl, jsonUrl) {
    try {
      const [img, data] = await Promise.all([
        this._loadImage(imgUrl),
        fetch(jsonUrl).then((r) => r.json()),
      ]);
      if (!img || !data) return false;

      this.effectsAtlas = {
        image: img,
        data,
        frameKeyCache: new Map(),
      };
      return true;
    } catch (e) {
      console.error("[AssetManager] Erro no effects atlas:", e);
      return false;
    }
  }

  hasEffectsAtlas() {
    return !!this.effectsAtlas?.image && !!this.effectsAtlas?.data;
  }

  getEffectSprite(effectId, elapsedMs = 0) {
    if (!this.hasEffectsAtlas()) return null;

    const key = String(effectId);
    const entry = this.effectsAtlas.data?.[key];
    if (!entry?.variants) return null;

    let frameKeys = this.effectsAtlas.frameKeyCache.get(key);
    if (!frameKeys) {
      frameKeys = Object.keys(entry.variants)
        .map(Number)
        .sort((a, b) => a - b);
      this.effectsAtlas.frameKeyCache.set(key, frameKeys);
    }
    if (!frameKeys.length) return null;

    let idx = 0;
    const phases = entry.animation?.phases;
    if (entry.is_animated && Array.isArray(phases) && phases.length > 0) {
      const durations = phases.map((p) => {
        const dMin = Number(p?.d_min ?? 100);
        const dMax = Number(p?.d_max ?? dMin);
        return Math.max(1, Math.round((dMin + dMax) / 2));
      });
      const total = durations.reduce((sum, d) => sum + d, 0);
      const loopTime = total > 0 ? elapsedMs % total : 0;

      let acc = 0;
      for (let i = 0; i < durations.length; i++) {
        acc += durations[i];
        if (loopTime < acc) {
          idx = i;
          break;
        }
      }
    }

    const clamped = Math.min(idx, frameKeys.length - 1);
    const variant = entry.variants[String(frameKeys[clamped])];
    if (!variant) return null;

    return {
      sheet: this.effectsAtlas.image,
      info: {
        x: Number(variant.x ?? 0),
        y: Number(variant.y ?? 0),
        w: Number(variant.w ?? entry.sprite_w ?? 32),
        h: Number(variant.h ?? entry.sprite_h ?? 32),
      },
      effectMeta: entry,
    };
  }

  /** Verifica se um pack já foi carregado. */
  hasPack(name) {
    return !!this.packs[name];
  }

  /** Retorna total de sprites de mapa carregados. */
  get spriteCount() {
    return this.sprites.size;
  }

  /** Retorna total de packs carregados. */
  get packCount() {
    return Object.keys(this.packs).length;
  }

  // ═══════════════════════════════════════════════════════════════
  // PRIVADO
  // ═══════════════════════════════════════════════════════════════

  _loadImage(url) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => {
        console.error(`[AssetManager] ❌ Falha ao carregar: ${url}`);
        resolve(null);
      };
      img.src = url;
    });
  }
}
