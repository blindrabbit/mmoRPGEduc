// ═══════════════════════════════════════════════════════════════
// mapRenderer.js — Módulo compartilhado de renderização de mapa
// Usado por: worldEngine.html, rpg.html (jogador), gm.html
// ═══════════════════════════════════════════════════════════════

import {
  TILE_SIZE,
  GROUND_Z,
  FLOOR_RANGE,
  WORLD_ENGINE,
} from "../core/config.js";

// Cache de variação por tile — compartilhado entre todas as engines
const _variantCache = new Map();

// Cache das sorted keys por sprite ID — evita Object.keys().sort() a cada frame
const _sortedKeysCache = new Map();

// ═══════════════════════════════════════════════════════════════
// SETUP DE CANVAS
// ═══════════════════════════════════════════════════════════════

export function setupCanvas(canvas, cols, rows) {
  canvas.width = cols * TILE_SIZE;
  canvas.height = rows * TILE_SIZE;
  return { canvasW: canvas.width, canvasH: canvas.height, cols, rows };
}

// ═══════════════════════════════════════════════════════════════
// CÂMERA
// ═══════════════════════════════════════════════════════════════

export function centerCamera(worldPos, cols, rows) {
  return {
    x: worldPos.x - Math.floor(cols / 2),
    y: worldPos.y - Math.floor(rows / 2),
  };
}

export function screenToTile(px, py, camera, zoom = 1) {
  return {
    tx: Math.floor(px / TILE_SIZE / zoom + camera.x),
    ty: Math.floor(py / TILE_SIZE / zoom + camera.y),
  };
}

// ═══════════════════════════════════════════════════════════════
// ÍNDICE POR FLOOR ← NOVO
// Chame buildFloorIndex(map) UMA vez após carregar o mapa.
// Passe o resultado como opts.floorIndex no renderMap.
// ═══════════════════════════════════════════════════════════════

/**
 * Constrói { z → Map("x,y,z" → { tx, ty, items }) }
 * Inclui tiles vazios (items:[]) para cobrir o chão pisável.
 */
export function buildFloorIndex(map) {
  const index = new Map();

  for (const [key, value] of Object.entries(map)) {
    // suporta formato flat [ids] e objeto { x,y,z,items }
    const items = Array.isArray(value) ? value : (value?.items ?? []);

    const parts = key.split(",");
    const tx = parseInt(parts[0]);
    const ty = parseInt(parts[1]);
    const z = parseInt(parts[2]);

    if (!index.has(z)) index.set(z, new Map());
    index.get(z).set(key, { tx, ty, items });
  }

  return index;
}

// ═══════════════════════════════════════════════════════════════
// HASH E VARIAÇÃO POR TILE
// ═══════════════════════════════════════════════════════════════

function tileHash(tx, ty, spriteId) {
  let h = (tx * 73856093) ^ (ty * 19349663) ^ (spriteId * 83492791);
  h = (((h >>> 16) ^ h) * 0x45d9f3b) | 0;
  h = (((h >>> 16) ^ h) * 0x45d9f3b) | 0;
  h = (h >>> 16) ^ h;
  return Math.abs(h);
}

export function getVariationIndex(tx, ty, spriteId, numVariacoes) {
  if (numVariacoes <= 1) return 0;
  const key = `${tx},${ty},${spriteId}`;
  if (!_variantCache.has(key)) {
    _variantCache.set(key, tileHash(tx, ty, spriteId) % numVariacoes);
  }
  return _variantCache.get(key);
}

// ═══════════════════════════════════════════════════════════════
// ANIMAÇÃO
// ═══════════════════════════════════════════════════════════════

export function getAnimFrameIndex(spriteData, animClock) {
  const anim = spriteData.animation;
  if (!anim?.phases?.length) return 0;

  const phases = anim.phases;
  const totalMs = phases.reduce((s, p) => s + (p.d || 200), 0);
  const clock = animClock % totalMs;

  let acc = 0;
  for (let i = 0; i < phases.length; i++) {
    acc += phases[i].d || 200;
    if (clock < acc) return i;
  }
  return phases.length - 1;
}

// ═══════════════════════════════════════════════════════════════
// RESOLUÇÃO DE VARIANT
// ═══════════════════════════════════════════════════════════════

export function resolveVariant(spriteData, tx, ty, animClock) {
  let sortedKeys = _sortedKeysCache.get(spriteData.id);
  if (!sortedKeys) {
    sortedKeys = Object.keys(spriteData.variants)
      .map(Number)
      .sort((a, b) => a - b);
    _sortedKeysCache.set(spriteData.id, sortedKeys);
  }

  const total = sortedKeys.length;
  const W = spriteData.pattern?.width ?? 1;
  const H = spriteData.pattern?.height ?? 1;

  if (W === 1 && H === 1) {
    const animFrame = spriteData.is_animated
      ? getAnimFrameIndex(spriteData, animClock) % total
      : 0;
    return spriteData.variants[String(sortedKeys[animFrame])];
  }

  const numVariacoes = W * H;
  const numFrames = Math.max(1, Math.floor(total / numVariacoes));
  const tipoBase = getVariationIndex(tx, ty, spriteData.id, numVariacoes);
  const animFrame = spriteData.is_animated
    ? getAnimFrameIndex(spriteData, animClock) % numFrames
    : 0;

  const variantIdx = tipoBase + animFrame * numVariacoes;
  const clampedIdx = Math.min(variantIdx, total - 1);
  return spriteData.variants[String(sortedKeys[clampedIdx])];
}

// ═══════════════════════════════════════════════════════════════
// DRAW SPRITE
// ═══════════════════════════════════════════════════════════════

export function drawSprite(
  ctx,
  atlas,
  nexoData,
  spriteId,
  sx,
  sy,
  tx,
  ty,
  animClock,
  alpha = 1.0,
) {
  if (spriteId === 0) return;

  const data = nexoData[String(spriteId)];
  if (!data) return;

  const variant = resolveVariant(data, tx, ty, animClock);
  if (!variant) return;

  const { x: atlasX, y: atlasY, w, h } = variant;

  const drawX = sx - (w - TILE_SIZE);
  const drawY = sy - (h - TILE_SIZE);

  if (alpha < 1.0) {
    ctx.save();
    ctx.globalAlpha = alpha;
  }

  ctx.drawImage(atlas, atlasX, atlasY, w, h, drawX, drawY, w, h);

  if (alpha < 1.0) ctx.restore();
}

function shouldForceToOverlay(spriteMeta, enabled) {
  if (!enabled || !spriteMeta) return false;

  const game = spriteMeta.game ?? {};
  const category = game.category_type;
  const width = spriteMeta?.pattern?.width ?? 1;
  const height = spriteMeta?.pattern?.height ?? 1;

  // Obstáculos altos (2x1, 1x2, 2x2...) sempre no topo.
  if (category === "obstacle" && (width > 1 || height > 1)) return true;

  // Folhagens/obstáculos naturais 1x1 que não são parede de LOS/projétil.
  // Mantém paredes sólidas fora dessa regra para não quebrar ocultação de interiores.
  if (
    category === "obstacle" &&
    game.is_walkable === false &&
    game.blocks_missiles !== true &&
    game.blocks_sight !== true
  ) {
    return true;
  }

  return false;
}

// ═══════════════════════════════════════════════════════════════
// ROOF FADE
// ═══════════════════════════════════════════════════════════════

function _floorHasTilesNearPlayer(map, z, camera, cols, rows, radius) {
  const cx = Math.floor(camera.x + cols / 2);
  const cy = Math.floor(camera.y + rows / 2);
  for (let dy = -radius; dy <= radius; dy++) {
    for (let dx = -radius; dx <= radius; dx++) {
      if (map[`${cx + dx},${cy + dy},${z}`]?.length > 0) return true;
    }
  }
  return false;
}

function _calcFloorAlphas(map, camera, activeZ, cols, rows, roofFadeRadius) {
  const alphas = new Map();

  for (let dz = FLOOR_RANGE; dz >= 0; dz--) {
    alphas.set(dz, 1.0);
  }

  let fadeFromDz = null;

  if (roofFadeRadius > 0) {
    for (let dz = -1; dz >= -FLOOR_RANGE; dz--) {
      const z = activeZ + dz;
      if (
        _floorHasTilesNearPlayer(map, z, camera, cols, rows, roofFadeRadius)
      ) {
        fadeFromDz = dz;
        break;
      }
    }
  }

  for (let dz = -1; dz >= -FLOOR_RANGE; dz--) {
    alphas.set(dz, fadeFromDz !== null && dz >= fadeFromDz ? 0.0 : 1.0);
  }

  return alphas;
}

// ═══════════════════════════════════════════════════════════════
// RENDER DO MAPA
// ═══════════════════════════════════════════════════════════════

export function renderMap(opts) {
  const {
    ctx,
    canvasW,
    canvasH,
    map,
    camera,
    activeZ,
    cols = WORLD_ENGINE.canvasCols,
    rows = WORLD_ENGINE.canvasRows,
    roofFadeRadius = 0,
    // Filtro de camada: só desenha sprites com render_layer em [layerMin, layerMax].
    // layerMin=0 / layerMax=3 = todos (comportamento padrão).
    // Use layerMax=2 no passe ANTES das entidades, layerMin=3 DEPOIS.
    layerMin = 0,
    layerMax = 3,
    // clearCanvas=false na segunda chamada (layer 3) para não apagar o frame.
    clearCanvas = true,
    // Permite filtrar andares por chamada (ex: só z>=activeZ, só z<activeZ).
    // Assinatura: (z, dz, activeZ) => boolean
    zPredicate = null,
    // Força obstáculos grandes (ex.: árvores) para overlay final
    // mesmo que o render_layer original esteja em 0..2.
    forceObstacleOverlay = false,
  } = opts;

  if (clearCanvas) {
    ctx.clearRect(0, 0, canvasW, canvasH);
    ctx.fillStyle = "#111";
    ctx.fillRect(0, 0, canvasW, canvasH);
  }

  const floorAlphas = _calcFloorAlphas(
    map,
    camera,
    activeZ,
    cols,
    rows,
    roofFadeRadius,
  );

  for (let dz = FLOOR_RANGE; dz >= -FLOOR_RANGE; dz--) {
    const z = activeZ + dz;
    if (typeof zPredicate === "function" && !zPredicate(z, dz, activeZ)) {
      continue;
    }

    _renderFloor({
      ...opts,
      z,
      dz,
      alpha: floorAlphas.get(dz) ?? 1.0,
      layerMin,
      layerMax,
      forceObstacleOverlay,
    });
  }
}

// ═══════════════════════════════════════════════════════════════
// RENDER FLOOR ← OTIMIZADO
// Se floorIndex estiver disponível: itera só a janela visível (O(1) por tile).
// Se não estiver: fallback para o comportamento original (compatibilidade).
// ═══════════════════════════════════════════════════════════════

function _renderFloor(opts) {
  const {
    ctx,
    atlas,
    nexoData,
    map,
    floorIndex,
    camera,
    z,
    animClock,
    canvasW,
    canvasH,
    cols = WORLD_ENGINE.canvasCols,
    rows = WORLD_ENGINE.canvasRows,
    alpha = 1.0,
    layerMin = 0,
    layerMax = 3,
    forceObstacleOverlay = false,
  } = opts;

  const floorOffset = (z - GROUND_Z) * TILE_SIZE;

  // ── MODO RÁPIDO: usa índice pré-calculado ──────────────────
  if (floorIndex) {
    const tiles = floorIndex.get(z);
    if (!tiles) return;

    const x0 = Math.floor(camera.x) - 2;
    const y0 = Math.floor(camera.y) - 2;
    const x1 = x0 + cols + 4;
    const y1 = y0 + rows + 4;

    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        const tile = tiles.get(`${tx},${ty},${z}`);
        if (!tile?.items.length) continue;

        const sx = Math.floor((tx - camera.x) * TILE_SIZE + floorOffset);
        const sy = Math.floor((ty - camera.y) * TILE_SIZE + floorOffset);

        for (const spriteId of tile.items) {
          const spriteMeta = nexoData?.[String(spriteId)];
          let renderLayer = spriteMeta?.game?.render_layer ?? 2;

          if (shouldForceToOverlay(spriteMeta, forceObstacleOverlay)) {
            renderLayer = 3;
          }

          if (renderLayer < layerMin || renderLayer > layerMax) continue;

          drawSprite(
            ctx,
            atlas,
            nexoData,
            spriteId,
            sx,
            sy,
            tx,
            ty,
            animClock,
            alpha,
          );
        }
      }
    }
    return;
  }

  // ── FALLBACK: comportamento original sem índice ────────────
  for (const [key, items] of Object.entries(map)) {
    const parts = key.split(",");
    if (parseInt(parts[2]) !== z) continue;

    const tx = parseInt(parts[0]);
    const ty = parseInt(parts[1]);

    const sx = Math.floor((tx - camera.x) * TILE_SIZE + floorOffset);
    const sy = Math.floor((ty - camera.y) * TILE_SIZE + floorOffset);

    if (sx + 64 < 0 || sx > canvasW + 64) continue;
    if (sy + 64 < 0 || sy > canvasH + 64) continue;

    for (const spriteId of items) {
      const spriteMeta = nexoData?.[String(spriteId)];
      let renderLayer = spriteMeta?.game?.render_layer ?? 2;

      if (shouldForceToOverlay(spriteMeta, forceObstacleOverlay)) {
        renderLayer = 3;
      }

      if (renderLayer < layerMin || renderLayer > layerMax) continue;

      drawSprite(
        ctx,
        atlas,
        nexoData,
        spriteId,
        sx,
        sy,
        tx,
        ty,
        animClock,
        alpha,
      );
    }
  }
}
