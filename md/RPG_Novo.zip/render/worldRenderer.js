// ═══════════════════════════════════════════════════════════════
// worldRenderer.js — Pipeline UNIFICADO v4
// Usado por: worldEngine.html, rpg.html, admin.html
// ✅ Outfits reais via AnimationController em TODAS as telas
// ═══════════════════════════════════════════════════════════════

import { TILE_SIZE, ENTITY_RENDER } from "../core/config.js";
import { OUTFIT_MAP } from "./outfitData.js";
import {
  getMonsterTemplates,
  inferSpeciesFromName,
} from "../core/remoteTemplates.js";
import { renderMap } from "./mapRenderer.js";
import { getMonsters, getPlayers } from "../core/worldStore.js";
import {
  drawCorpses,
  drawVisualEffects,
  drawFloatingTexts,
} from "../gameplay/gameCore.js";

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

/**
 * Resolve o nome de exibição de uma entidade.
 * Para MONSTROS: template > species > name (Firebase name é genérico)
 * Para PLAYERS: name > template > species
 * Garante sempre retornar algo para exibição (nunca null)
 */
// converte algo como "giant_rat" ou "Rat" para "Giant Rat" (camel‑case simples)
function toCamelCase(str) {
  if (!str || typeof str !== "string") return str;
  return str.replace(/[_-]/g, " ").replace(/\b\w/g, (m) => m.toUpperCase());
}

function resolveDisplayName(ent, id, isMonster, remoteTemplates) {
  // Prefere o nome explícito do monstro/jogador quando existe
  if (ent.name) return toCamelCase(ent.name);

  if (isMonster) {
    // tenta obter nome a partir do template remoto (caso ent.name não existisse)
    if (remoteTemplates && ent.species) {
      const tmpl = remoteTemplates[ent.species];
      if (tmpl && tmpl.name) return toCamelCase(tmpl.name);
    }
    // otherwise fallback to template key or species
    if (ent.template) return toCamelCase(ent.template);
    if (ent.species) return toCamelCase(ent.species);
  } else {
    if (ent.template) return toCamelCase(ent.template);
    if (ent.species) return toCamelCase(ent.species);
  }

  // última tentativa: inferir do ID
  if (typeof id === "string") {
    const parts = id.split("_");
    if (parts.length >= 2) return toCamelCase(parts[1]);
  }

  // último recurso genérico
  return toCamelCase(typeof id === "string" ? id.substring(0, 12) : "?");
}

/**
 * Calcula cor de vida com gradiente suave:
 * 100% = Verde (#00FF00)
 * 75% = Amarelo-Verde
 * 50% = Amarelo (#FFFF00)
 * 25% = Laranja/Vermelho (#FF8800)
 * 0% = Preto (#000000)
 */
function getHealthColor(pct) {
  pct = Math.max(0, Math.min(1, pct));
  let r, g, b;

  if (pct >= 0.75) {
    // Verde ao Amarelo-Verde (100% a 75%)
    const t = (1 - pct) / 0.25;
    r = Math.floor(255 * t);
    g = 255;
    b = 0;
  } else if (pct >= 0.5) {
    // Amarelo-Verde ao Amarelo-Laranja (75% a 50%)
    const t = (0.75 - pct) / 0.25;
    r = 255;
    g = Math.floor(255 * (1 - t * 0.5));
    b = 0;
  } else if (pct >= 0.25) {
    // Amarelo-Laranja ao Vermelho (50% a 25%)
    const t = (0.5 - pct) / 0.25;
    r = 255;
    g = Math.floor(127 * (1 - t));
    b = 0;
  } else {
    // Vermelho ao Preto (25% a 0%)
    const t = (0.25 - pct) / 0.25;
    r = Math.floor(255 * (1 - t));
    g = 0;
    b = 0;
  }

  return `#${r.toString(16).padStart(2, "0")}${g.toString(16).padStart(2, "0")}${b.toString(16).padStart(2, "0")}`;
}

// ═══════════════════════════════════════════════════════════════
// RENDER DE ENTIDADES — dois passes para garantir z-order correto
//
// Pass 1: todos os sprites/corpos
// Pass 2: todos os labels (HP bar + nome) por cima de tudo
//
// Isso garante que nomes e barras nunca fiquem atrás de outro
// sprite, mesmo quando o player passa em cima do monstro.
// ═══════════════════════════════════════════════════════════════
function renderEntitiesFull(
  ctx,
  entities,
  assets,
  anim,
  camX,
  camY,
  activeZ,
  ts,
  {
    showHP = true,
    showName = true,
    renderMode = "high",
    labelsSameFloorOnly = false,
  },
) {
  // Obtém templates uma vez para todo o loop — evita chamada por entidade
  const remote = getMonsterTemplates();

  // Coleta entidades visíveis com posições já calculadas para reusar no pass 2
  const visible = [];

  // ── Pass 1: sprites/corpos ────────────────────────────────────
  for (const id in entities) {
    const ent = entities[id];
    if (!ent || (ent.z ?? 7) !== activeZ || ent.dead) continue;

    // Guarda contra entidades com x/y inválidos (ainda sincronizando do Firebase)
    if (ent.x == null || ent.y == null || isNaN(ent.x) || isNaN(ent.y))
      continue;

    // ── Posição visual interpolada ────────────────────────────────
    const safeEnt =
      ent.oldX == null || ent.oldY == null
        ? { ...ent, oldX: ent.oldX ?? ent.x, oldY: ent.oldY ?? ent.y }
        : ent;

    const vPos =
      assets && anim
        ? anim.getVisualPos(safeEnt)
        : { x: ent.x * TILE_SIZE, y: ent.y * TILE_SIZE };

    // Centro do tile na tela (usado para culling e fallback)
    const drawX = Math.round(vPos.x - camX + TILE_SIZE / 2);
    const drawY = Math.round(vPos.y - camY + TILE_SIZE / 2);

    // Centro visual do sprite (alinhado com ENTITY_RENDER — usado para labels)
    const labelX = Math.round(
      vPos.x -
        camX +
        TILE_SIZE / 2 +
        ENTITY_RENDER.offsetX +
        ENTITY_RENDER.labelOffsetX,
    );
    const spriteTopY = Math.round(
      vPos.y -
        camY +
        Math.round(TILE_SIZE * ENTITY_RENDER.footAnchorY) -
        TILE_SIZE +
        ENTITY_RENDER.offsetY,
    );

    // Culling
    if (
      drawX < -64 ||
      drawX > ctx.canvas.width + 64 ||
      drawY < -64 ||
      drawY > ctx.canvas.height + 64
    )
      continue;

    const isMonster =
      ent.type === "monster" ||
      typeof ent.species === "string" ||
      (typeof id === "string" && id.startsWith("mob"));
    const isAdminEnt = ent.id === "GMADMIN" || ent.appearance?.isAdmin;

    // Infere species pelo nome se não vier do Firebase
    let species = ent.species;
    if (isMonster && !species && remote) {
      const inferred = inferSpeciesFromName(ent.name ?? ent.template);
      if (inferred) species = inferred;
    }

    // Resolve pack e outfitId
    const defaultPack = isMonster ? "monstros_01" : "outfits_01";
    let pack = ent.appearance?.outfitPack || defaultPack;
    let outfitIdRaw = ent.appearance?.outfitId ?? species ?? ent.template;
    let outfitId =
      outfitIdRaw != null ? outfitIdRaw : isMonster ? "rat" : 10000;

    if (isMonster && remote && species && remote[species]) {
      const tmplApp = remote[species].appearance || {};
      pack = tmplApp.outfitPack || ent.appearance?.outfitPack || pack;
      outfitId = tmplApp.outfitId || ent.appearance?.outfitId || outfitId;
    }

    // Pack fallback se não carregado ainda
    let resolvedPack = pack;
    if (
      assets &&
      typeof assets.hasPack === "function" &&
      !assets.hasPack(resolvedPack)
    ) {
      const fallbackPack = isMonster ? "monstros_01" : "outfits_01";
      if (assets.hasPack(fallbackPack)) resolvedPack = fallbackPack;
    }

    const hasOutfitConfig = !!OUTFIT_MAP[outfitId];
    const hasOutfitAtlasDef = !!(
      assets &&
      typeof assets.hasOutfitDefinition === "function" &&
      assets.hasOutfitDefinition(outfitId)
    );
    const hasPackLoaded =
      assets && typeof assets.hasPack === "function"
        ? assets.hasPack(resolvedPack)
        : false;
    const hasOutfitAtlasLoaded = !!(
      assets &&
      typeof assets.hasOutfitsAtlas === "function" &&
      assets.hasOutfitsAtlas()
    );

    const canMonsterSprite = hasOutfitConfig && hasPackLoaded;
    const canPlayerSprite = hasOutfitAtlasDef && hasOutfitAtlasLoaded;
    const canSprite =
      assets &&
      anim &&
      renderMode !== "low" &&
      (isMonster ? canMonsterSprite : canPlayerSprite);

    if (canSprite) {
      if (window.DEBUG_SPRITES) {
        console.log(
          "[renderEntitiesFull]",
          id,
          ent.type,
          "pack=",
          resolvedPack,
          "outfit=",
          outfitId,
          "dir=",
          ent.direcao,
          "moving=",
          ent.x !== (ent.oldX ?? ent.x) || ent.y !== (ent.oldY ?? ent.y),
        );
      }
      const entForDraw = {
        ...safeEnt,
        appearance: {
          ...(safeEnt.appearance || {}),
          outfitPack: resolvedPack,
          outfitId,
        },
      };
      if (window.DEBUG_SPRITES_VERBOSE) {
        console.debug(
          "[SPRITES_DEBUG] entity=",
          id,
          "appearance=",
          entForDraw.appearance,
          "resolvedPack=",
          resolvedPack,
        );
      }
      anim.drawManual(ctx, assets, entForDraw, vPos.x, vPos.y, camX, camY);
    } else {
      if (window.DEBUG_SPRITES) {
        console.log(
          "[renderEntitiesFull] fallback",
          id,
          ent.type,
          "pack=",
          resolvedPack,
          "outfit=",
          outfitId,
          "hasOutfit=",
          isMonster ? hasOutfitConfig : hasOutfitAtlasDef,
          "hasPack=",
          isMonster ? hasPackLoaded : hasOutfitAtlasLoaded,
        );
      }
      // Fallback: círculo colorido
      ctx.beginPath();
      ctx.arc(drawX, drawY, isMonster ? 8 : 6, 0, Math.PI * 2);
      ctx.fillStyle = isAdminEnt
        ? "#3c9de7"
        : isMonster
          ? "#e74c3c"
          : "#2ecc71";
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,0.3)";
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    // Guarda dados para o pass 2 (labels)
    visible.push({ id, ent, drawX, drawY, labelX, spriteTopY, isMonster });
  }

  // ── Pass 2: HP bars + nomes — sempre por cima de todos os sprites ──
  for (const {
    id,
    ent,
    drawX,
    drawY,
    labelX,
    spriteTopY,
    isMonster,
  } of visible) {
    if (labelsSameFloorOnly && (ent.z ?? 7) !== activeZ) continue;

    const hp = ent.stats?.hp ?? 100;
    const maxHp = ent.stats?.maxHp ?? 100;

    // HP Bar — centralizada no sprite, posicionada pelo ENTITY_RENDER.labelBarY
    if (showHP && maxHp) {
      const pct = Math.max(0, Math.min(1, hp / maxHp));
      const bw = TILE_SIZE,
        bh = 4;
      const bx = labelX - TILE_SIZE / 2;
      const by = spriteTopY + ENTITY_RENDER.labelBarY;
      ctx.fillStyle = "#1a1a1a";
      ctx.fillRect(bx, by, bw, bh);
      ctx.fillStyle = getHealthColor(pct);
      ctx.fillRect(
        bx + 1,
        by + 1,
        Math.max(1, Math.round((bw - 2) * pct)),
        bh - 2,
      );
      ctx.strokeStyle = "#000";
      ctx.lineWidth = 0.5;
      ctx.strokeRect(bx, by, bw, bh);
    }

    // Nome — centralizado no sprite, posicionado pelo ENTITY_RENDER.labelNameY
    if (showName) {
      const displayName = resolveDisplayName(ent, id, isMonster, remote);
      if (displayName) {
        const pct = Math.max(0, Math.min(1, hp / maxHp));
        const nameY = spriteTopY + ENTITY_RENDER.labelNameY;
        ctx.save();
        ctx.font = "bold 10px monospace";
        ctx.textAlign = "center";
        ctx.textBaseline = "alphabetic";
        ctx.lineWidth = 2;
        ctx.strokeStyle = "rgba(0,0,0,0.9)";
        ctx.strokeText(displayName, labelX, nameY);
        ctx.fillStyle = getHealthColor(pct);
        ctx.fillText(displayName, labelX, nameY);
        ctx.restore();
      }
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// PIPELINE PRINCIPAL
// ═══════════════════════════════════════════════════════════════
export function renderWorld({
  ctx,
  camX,
  camY,
  activeZ,
  animClock,
  ts,
  canvasW,
  canvasH,
  cols,
  rows,
  atlas,
  nexoData,
  map,
  assets,
  anim,
  floorIndex = null,
  roofFadeRadius = 0,
  extraEntities = {},
  renderOptions = { showHP: true, showName: true, renderMode: "high" },
}) {
  const { showHP, showName } = renderOptions;
  const lockTarget = renderOptions.lockTarget ?? null;
  // Compatibilidade: aceita 'renderMode' (novo) e 'mode' (legado)
  const renderMode = renderOptions.renderMode ?? renderOptions.mode ?? "high";
  const isPlayerView =
    renderOptions.isPlayer === true || renderOptions.viewMode === "player";
  const labelsSameFloorOnly = renderOptions.labelsSameFloorOnly ?? isPlayerView;

  const _mapBase = {
    ctx,
    atlas,
    nexoData,
    map,
    floorIndex,
    camera: { x: camX / TILE_SIZE, y: camY / TILE_SIZE },
    activeZ,
    animClock,
    canvasW,
    canvasH,
    cols,
    rows,
    roofFadeRadius,
    forceObstacleOverlay: true,
  };

  // 1. Mapa base (andar ativo e abaixo) — layers 0-2
  //    Isso garante entidades sobre o próprio chão, mas ainda permite
  //    andares ACIMA cobrirem depois (passo 6).
  renderMap({
    ..._mapBase,
    layerMax: 2,
    zPredicate: (z, _dz, aZ) => z >= aZ,
  });

  // 2. Cadáveres
  drawCorpses?.(ctx, assets, camX, camY, ts);

  // 3. Efeitos de chão
  drawVisualEffects?.(ctx, assets, camX, camY, "ground");

  // 4. Entidades
  let allEntities;
  if (Object.keys(extraEntities).length > 0) {
    // Admin/GM: extraEntities contém tudo — não usa worldStore
    allEntities = extraEntities;
  } else {
    // RPG: worldStore, filtra mortos e cadáveres
    const livingMonsters = {};
    const monsters = getMonsters();
    for (const id in monsters) {
      const m = monsters[id];
      if (m && !m.dead && m.type !== "corpse") livingMonsters[id] = m;
    }
    allEntities = { ...livingMonsters, ...getPlayers() };
  }

  // 4.1 Marcador de lock target (ABAIXO dos sprites)
  if (lockTarget?.id) {
    const locked = allEntities?.[lockTarget.id];
    if (locked && !locked.dead && (locked.z ?? 7) === activeZ) {
      const px = Math.round(locked.x * TILE_SIZE - camX);
      const py = Math.round(locked.y * TILE_SIZE - camY);
      ctx.save();
      ctx.strokeStyle = "#ff2e2e";
      ctx.lineWidth = 2;
      ctx.strokeRect(px, py, TILE_SIZE, TILE_SIZE);
      ctx.restore();
    }
  }

  renderEntitiesFull(ctx, allEntities, assets, anim, camX, camY, activeZ, ts, {
    showHP,
    showName,
    renderMode,
    labelsSameFloorOnly,
  });

  // 5. Efeitos de topo
  drawVisualEffects?.(ctx, assets, camX, camY, "top");

  // 6. Mapa de andares acima (z < activeZ) — layers 0-2
  //    Corrige sobreposição entre camadas distintas:
  //    paredes/pisos de andares superiores ficam por cima do que está abaixo.
  renderMap({
    ..._mapBase,
    layerMax: 2,
    clearCanvas: false,
    zPredicate: (z, _dz, aZ) => z < aZ,
  });

  // 7. Textos flutuantes
  drawFloatingTexts?.(ctx, camX, camY);

  // 8. Mapa — layer 3 (top_decoration: copas de árvore, telhados)
  //    Renderizado APÓS entidades para cobrir personagens que passam por baixo.
  renderMap({ ..._mapBase, layerMin: 3, layerMax: 3, clearCanvas: false });
}
