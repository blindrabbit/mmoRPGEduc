// ═══════════════════════════════════════════════════════════════
// assetLoader.js — Carregamento de sprites e packs de assets
// Usado por: rpg.html, gm.html, worldEngine.html
// ═══════════════════════════════════════════════════════════════

/**
 * Carrega automaticamente todos os packs de sprites disponíveis.
 * Carrega apenas os packs iniciais (01) de outfits e monstros.
 * Efeitos visuais agora usam effects_atlas.png + effects_data.json.
 * @param {AssetManager} assets — instância do gerenciador de assets
 * @param {string} basePath     — caminho base (ex: "./assets/")
 * @returns {Promise<number>}   — total de packs carregados
 */
export async function loadAllSprites(assets, basePath = "../assets/") {
  const prefixes = ["monstros"];
  let total = 0;

  try {
    const outfitsJson = `${basePath}outfits_players_data.json`;
    const outfitsImg = `${basePath}outfits_players_atlas.png`;
    const outfitsRes = await fetch(outfitsJson);
    if (outfitsRes.ok && typeof assets.loadOutfitsAtlas === "function") {
      await assets.loadOutfitsAtlas(outfitsImg, outfitsJson);
    }
  } catch (e) {
    console.warn(
      "[assetLoader] outfits atlas não carregado:",
      e?.message ?? e,
    );
  }

  try {
    const atlasJson = `${basePath}effects_data.json`;
    const atlasImg = `${basePath}effects_atlas.png`;
    const atlasRes = await fetch(atlasJson);
    if (atlasRes.ok && typeof assets.loadEffectsAtlas === "function") {
      await assets.loadEffectsAtlas(atlasImg, atlasJson);
    }
  } catch (e) {
    console.warn("[assetLoader] effects atlas não carregado:", e?.message ?? e);
  }

  try {
    const fieldsJson = `${basePath}fields_data.json`;
    const fieldsImg = `${basePath}fields_atlas.png`;
    const fieldsRes = await fetch(fieldsJson);
    if (fieldsRes.ok && typeof assets.loadFieldsAtlas === "function") {
      await assets.loadFieldsAtlas(fieldsImg, fieldsJson);
    }
  } catch (e) {
    console.warn("[assetLoader] fields atlas não carregado:", e?.message ?? e);
  }

  for (const prefix of prefixes) {
    const id = "01";
    const name = `${prefix}_${id}`;

    // Note que usamos o nome com "__" para o JSON conforme seu padrão solicitado
    const imagePath = `${basePath}${prefix}_${id}.png`;
    const jsonPath = `${basePath}${prefix}_${id}.json`;

    try {
      // Verifica se o JSON existe antes de carregar o pack
      const res = await fetch(jsonPath);

      if (res.ok) {
        await assets.loadPack(name, imagePath, jsonPath);
        total++;
        // console.log(`Sucesso ao carregar: ${name}`);
      } else {
        console.warn(`Arquivo não encontrado: ${jsonPath}`);
      }
    } catch (error) {
      console.error(`Erro ao carregar o pack ${name}:`, error);
    }
  }
  return total;
}

/**
 * Carrega um pack específico pelo nome.
 * Útil para carregar sob demanda.
 *
 * @param {AssetManager} assets
 * @param {string} name     — ex: "outfits_01"
 * @param {string} basePath
 */
export async function loadPack(assets, name, basePath = "./assets/") {
  const packName = String(name || "");
  const isLegacyOutfitPack = packName.startsWith("outfits_");

  if (isLegacyOutfitPack) {
    if (typeof assets?.hasOutfitsAtlas === "function" && assets.hasOutfitsAtlas()) {
      return true;
    }
    console.warn(
      `[assetLoader] Pack legado ignorado (${packName}) sem atlas de outfits carregado.`,
    );
    return false;
  }

  await assets.loadPack(
    packName,
    `${basePath}${packName}.png`,
    `${basePath}${packName}.json`,
  );

  return true;
}
